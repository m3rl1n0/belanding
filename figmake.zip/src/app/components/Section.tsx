import { motion, useInView } from "motion/react";
import clsx from "clsx";
import { useRef } from "react";

interface SectionProps {
  id: string;
  text: string;
  index: number;
  theme: 'dark' | 'light';
}

const MolecularText = ({ text }: { text: string }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-10% 0px -10% 0px" });

  // Split text into lines to preserve newlines from "whitespace-pre-line" intent
  const lines = text.split('\n');

  return (
    <p 
      ref={ref} 
      className="font-['Inter_Tight',sans-serif] text-2xl md:text-4xl lg:text-5xl leading-[1.15] font-light tracking-tight max-w-4xl"
    >
      {lines.map((line, lineIndex) => (
        <span key={lineIndex} className="block">
          {line.split(' ').map((word, wordIndex) => (
            <span key={wordIndex} className="inline-block whitespace-nowrap mr-[0.25em]">
              {word.split('').map((char, charIndex) => {
                // More chaotic/molecular random values
                const randomX = (Math.random() - 0.5) * 150; // Increased scatter range
                const randomY = (Math.random() - 0.5) * 150; // Increased scatter range
                const randomScale = 0.5 + Math.random() * 2; // Random scale between 0.5 and 2.5
                
                return (
                  <motion.span
                    key={charIndex}
                    className="inline-block"
                    initial={{ 
                      opacity: 0, 
                      filter: "blur(15px)", 
                      x: randomX, 
                      y: randomY,
                      scale: randomScale,
                    }}
                    animate={isInView ? { 
                      opacity: 1, 
                      filter: "blur(0px)", 
                      x: 0, 
                      y: 0,
                      scale: 1
                    } : {}}
                    transition={{ 
                      duration: 0.5, // Faster duration
                      delay: (lineIndex * 0.1) + (wordIndex * 0.05) + (charIndex * 0.01), // Faster stagger
                      ease: "easeOut" 
                    }}
                  >
                    {char}
                  </motion.span>
                );
              })}
            </span>
          ))}
        </span>
      ))}
    </p>
  );
};

export const Section = ({ id, text, index, theme }: SectionProps) => {
  const isDark = theme === 'dark';
  
  return (
    <section 
      className={clsx(
        "w-full py-24 border-b transition-colors duration-500",
        isDark ? "bg-[#111] text-white border-white/10" : "bg-white text-black border-black/10"
      )}
    >
      <div className="w-full h-full flex flex-col md:flex-row">
        
        {/* Left Column (30%) - Number */}
        <div className={clsx(
          "w-full md:w-[30%] flex flex-col justify-start md:items-end px-6 md:px-8 border-b md:border-b-0 md:border-r pb-8 md:pb-0 relative",
          isDark ? "border-white/20" : "border-black/20"
        )}>
           {/* Mobile Line */}
           <div className={clsx("absolute bottom-0 left-0 w-full h-px md:hidden", isDark ? "bg-white/20" : "bg-black/20")} />

          <motion.span 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="font-['Ivy_Presto_Display','Playfair_Display',serif] text-8xl md:text-9xl lg:text-[10rem] font-light leading-none opacity-50 block"
          >
            {id}
          </motion.span>
        </div>

        {/* Right Column (70%) - Content */}
        <div className="w-full md:w-[70%] px-6 md:px-16 pt-8 md:pt-4 flex flex-col justify-center">
            <MolecularText text={text} />
        </div>

      </div>
    </section>
  );
};
